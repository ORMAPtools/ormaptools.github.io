# Update MapIndex
# This python goes with the UpdateMapIndex Script in the template
#
# In the tool you can enter all the basic map info and it will update it.
# EXCEPT: it will not update mapnumber, mapscale or county if you already have one
#
# You can also adjust many of the parameters to cutomize the tool so that thinks like town and range
# will have a pull down list for only those in your township. 
#
# it can be customized for different layers by changing the MapIndexLayer and MapName Parameters to match your flavor.
#
#
# Dean - 1/25/2020 


import arcpy 

# Get your parameters -------------------------------------------------

MapNumber = str(arcpy.GetParameterAsText(0))
MapScale = arcpy.GetParameterAsText(1)
County = str(arcpy.GetParameterAsText(2))
ReliaCode = arcpy.GetParameterAsText(3)
T = str(arcpy.GetParameterAsText(4))
TP = str(arcpy.GetParameterAsText(5))
TD = str(arcpy.GetParameterAsText(6))
R = str(arcpy.GetParameterAsText(7))
RP = str(arcpy.GetParameterAsText(8))
RD = str(arcpy.GetParameterAsText(9))
S = str(arcpy.GetParameterAsText(10))
Q = str(arcpy.GetParameterAsText(11))
QQ = str(arcpy.GetParameterAsText(12))
A = str(arcpy.GetParameterAsText(13))
MST = str(arcpy.GetParameterAsText(14))
MSN = str(arcpy.GetParameterAsText(15))
CityName = str(arcpy.GetParameterAsText(16))
PageName = str(arcpy.GetParameterAsText(17))
Book = arcpy.GetParameterAsText(18)
GroupName = str(arcpy.GetParameterAsText(19))
SecondTitle = str(arcpy.GetParameterAsText(20))
MapAngle = arcpy.GetParameterAsText(21)
MapIndexLayer = str(arcpy.GetParameterAsText(22))

arcpy.AddMessage("MapIndex: " + MapIndexLayer)


# Set Layer and ensure only 1 feature selected ---------------------------

thisProject = arcpy.mp.ArcGISProject("CURRENT")
#editMap = thisProject.listMaps("ORMapEdit")[0]
editMap = thisProject.activeMap
MapLayer = editMap.listLayers(MapIndexLayer)[0]

MapLayerCnt = int(arcpy.GetCount_management(MapLayer).getOutput(0))
arcpy.AddMessage (MapLayerCnt)

# Check if you have one feature selected and the form entered --------------

if MapLayerCnt > 1:
    arcpy.AddError ("More then one feature selected")
if Q == "0" and QQ != "0":
    arcpy.AddError ("Quarter/Quarter is filled but Quarter is not")
if Q != "0" and S == "00":
    arcpy.AddError ("Can not have a section 00 with quartersections filled")

# Calc Map Title----------------------Any county specific code for suffixes etc goes here ----------------------------------------
# T/R/S does a str/int to get rid of leading zeroes
 
qs = ['',' N.E.1/4 ',' N.W.1/4 ',' S.W.1/4 ',' S.E.1/4 ']
qtrs = ['0','A','B','C','D']
Title = "T." + str(int(T)) + " " + TD + ". R." + str(int(R)) + " " + RD + ". W.M."
if S != "00":   
    QT = ""
    QQT = "" 
    x = 0
    for q in qtrs:
        arcpy.AddMessage(x) 
        if q == Q:
            QT = qs[x]
        if q == QQ:
            QQT = qs[x] 
        x = x + 1
    Title = QQT + QT + "SEC. " + str(int(S)) + ' ' + Title

# Calc Values ------------------------------------------------------------------------
#                                         0           1          2       3          4            5       6        7           8           9           10          11 
with arcpy.da.UpdateCursor(MapLayer,['MapNumber','MapScale','County','ORMapNum','CityName','PageName','Book','GroupName','SecondTitle','ReliaCode','MapAngle',"MapTitle"]) as cursor:
    for row in cursor:
        if row[0] is None:
            if MapNumber is None:
#---------------------------------- Place your code to update the mapnumber here...
                MapNumber = str(int(T)) + '.' + str(int(R)) + '.' + str(int(S)) + Q + QQ 
            row[0] = MapNumber
        if row[1] is None:       
            row[1] = MapScale
        if row[2] is None:               
            row[2] = County
        row[3] = County + T + TP + TD + R + RP + RD + S + Q + QQ + A + MST + MSN
        row[4] = CityName
        row[5] = PageName
        row[7] = GroupName
        row[8] = SecondTitle
        if ReliaCode.isnumeric(): row[9] = ReliaCode
        if MapAngle.isnumeric(): row[10] = MapAngle
        row[11] = Title 
        if Book.isnumeric(): row[6] = Book
        cursor.updateRow(row)
del row                







