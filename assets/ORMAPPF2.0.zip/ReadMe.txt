ReadMe - Version 2.0 
1/15/2022

Design 2.0 

ArcPro 2.8.3 


Notes - Not much has changed from the previous release.  This was created in ArcGIS Pro 2.8.3.  Dean 1/12/2022
 
Minor Changes 

Update 
-- Added Attribute Rule
-- Added Operations domain for Record Type (Records) 
-- Non-Fabric Feature classes (AnnoClass, MapIndex, Cartographiclines Etc.) - CreatedByRecord changed DataType - GUID - Text 

Not Changed 
Taxcode Is Not Part of the fabric 

This directory is an ArcPro workspace. 

CountySamples - where stuff from participating counties will go (has attribute rules from Multnomah) 
Default.gdb - Started ESRI Database 
Documents - Design Documents (Original Design from 2006 and the New Draft Design) 
ImportLog - Standard ESRI Log 
Index - Standard ESRI Index subdirectory 
ORMAPPFTemplate.gdp - The new database template (includes empty feature classes, fields, and domains) 
Default.tbx - default tool box 
OrMapPF.aprx - ESRI project file 
AttributeRuleSamles - Contains samples of attribute rules from users. 

To Set This Up

1. Have ArcPro installed 2.8.3 or greater on recommended machines
2. Must  a working knowlege of ArcPro (Editing, MapLayouts, Feature Class Design, Catalogue) 
3. Have a working knowlege of Arcade 
4. Have a working knowlege of Parcel Fabric (Take the ESRI ArcPro class) 

 




