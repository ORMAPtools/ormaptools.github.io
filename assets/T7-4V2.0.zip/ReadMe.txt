ORMAP Sample DataSet 

1/15/2022 

ArcPro 2.8.3 

Fabric - A single township directory converted to the new standard with some additions added to support 
Polk County functions.  For example, Taxcode is now a Fabric feature class 

GeoDb - The ArcMap geodatabase that is in Polk County's version of the Old ORMAP ArcMap Data standard. 

1. To See It Work... 
-- Copy the contents to:  C:\ORMAPV2\T7-4V2.0
-- Go To C:\ORMAPV2\T7-4V2.0\Fabric 
-- Open OrMapPF.aprx

2. To See Pre-Converted GeoDatabase 
-- After contents setup to:  C:\ORMAPV2\T7-4V2.0
-- Go To C:\ORMAPV2\T7-4V2.0\GeoDB
-- Open mapreview_v106.mxd

3. To Run Conversion (This will delete the current version and replace it with data from GeoDatabase) 
-- After contents setup to:  C:\ORMAPV2\T7-4V2.0
-- Go To C:\ORMAPV2\T7-4V2.0\Fabric\FabricConversion 
-- Run AP-00driveArcProPy.bat  (This is a batch job the runs 10 Python conversion scripts) 

4. To Install Two Addins for the ArrowTool and Cancelled Number Tool 
-- After contents setup to:  C:\ORMAPV2\T7-4V2.0
-- Go To C:\ORMAPV2\T7-4V2.0\Fabric\ORMAPTools
-- Double clickin on the Addins 
-----> ORMAPArrowTools-20220110-0930.esriAddinX
-----> ORMAPCancelledNumbers.esriAddinX

5. To See basic documentation on tools 
-- After contents setup to:  C:\ORMAPV2\T7-4V2.0
-- Go To C:\ORMAPV2\T7-4V2.0\Fabric\ORMAPTools
----> Open "ORMAPTOOLSDoc.pptx" to view a tools summary 
----> Open "ORMAP Arrow Tool.docx" to see the Arrow Tool Documentation 



