ORMAP Sample DataSet 
1/15/2022 

ArcPro 2.8.3 

Fabric - A single township directory converted to the new standard with some additions added to support 
Polk County functions.  For example, Taxcode is now a Fabric feature class
.backups - ESRI standard subdirectory for project folder 
Default.gdb - ESRI standard file for project folder - used for storage of temporary/working feature classes 
FabricConversion - Contains fabric conversion scripts 
GISLogs - Location of log text files created during the fabric conversion 
ImportLog - ESRI standard subdirectory for project folder
Index - ESRI standard subdirectory for project folder
ORMAPTools - python scripts used when working with the polk county dataset 
TownEd.gdb - geodatabase containing feature classes the meet the ORMAP standard 
TownEdbk.gdb -empty geodatabase that can be used as a template for conversion 
.pyHistory - ESRI standard file for project folder
ArrowTools_Required_Scales.txt - created/used by the add arrow tool 
Default.tbx - Tool box containing ORMAP tools
OrMapPF.aprx - Project file 


See ORMAPTOOLSDoc.pptx 

