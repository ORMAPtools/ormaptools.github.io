ORMAPTools Update 9/10/2022

Updated the Update ORMAPArea to (was called TaxlotAcres instead of TaxlotAcre) 

Default.tbx 

CreateDDAnnoFromLabels (AddDimAnno.py) - Creates dimension annotation from labels 
UpdateMapIndex (UpdateMapIndex.py) - Updates mapindex attribues 
UpdateORMAPArea (UpdateORMAPArea.py) - Updates required ORMAP attribute fields 
ZoomToMap - No python scrpt 

Addins are available for installation from the GitHub Site 

  https://github.com/ormaptools

Documentation 

ORMAP Arrow Tool.docx - documentation for Arrow TOol 
ORMAP TOOLS Doc.pdf - documentation for all tools 

