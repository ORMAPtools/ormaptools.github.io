# ExportAllAttributeRules.py
#
# Exportal Attribute rules for layer list from a GDB to external CSV's
#
# Inputs: 
#   OutGDB - Location of Geodatabase that will contain the rules                  
#   Layers - ['List of Layers to Import']
#   CSVFileLocation - Location of CSV Files
#
# - From Layer list build layer
# - For each layer build path to CSV and Layer and csv paths
# - Delete CSV and XML file for each layer
# - Export rules 
# 
# Note: layers in the fabric need FeatureDataset added to the path
#
# Dean - 5/2022 
#

import arcpy, sys 

InGDB = "C:\\ORMAP3.0\\T7-4\\Fabric\\TownEd.gdb"              
Layers = ['Anno0100Scale','Anno0200Scale','Anno0400Scale','Anno2000Scale','Taxlot','CartographicLines','PLSSLines','WaterLines','ReferenceLines','ConstructionLines']
OutFileLocation = "C:\\ORMAP3.0\\T7-4\\Fabric\RuleExports"

for Layer in Layers:
    csvFile = OutFileLocation + "\\" + Layer + ".csv"
    xmlFile = OutFileLocation + "\\" + Layer + ".csv.xml"
    InTable = InGDB + "\\" + Layer
    
    if Layer == "Taxlot" or Layer == "TaxlotNumberAnno":
        InTable = InGDB + "\\TaxlotsFD\\" + Layer 
    else:
        InTable = InGDB + "\\" + Layer
        
    print ('Layer: ' + Layer)

    # Delete CSV file (do not need to see if it exists)
    
    arcpy.Delete_management(csvFile)
    arcpy.Delete_management(xmlFile)

    # Export Rules to csvFile 
        
    arcpy.management.ExportAttributeRules(InTable, csvFile)
