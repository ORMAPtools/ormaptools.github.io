# ImportAllAttributeRules.py
#
# Import Attribute rules stored as CSV's in a directory into a Geodatabase for each layer in a layer list 
#
# Inputs: 
#   OutGDB - Location of Geodatabase that will contain the rules                  
#   Layers - ['List of Layers to Import']
#   CSVFileLocation - Location of CSV Files
#
# Steps
#     Check if CSV file exists for layer and if so call ImportRules function
#     Import Rules Function
#         - Read CSV to get list of rules to delete (only delete rules that are in the CSV
#         - Delete rules one at a time (cause thats how it works) 
#         - Import rules from the CSV 
#
# Note: layers in the fabric need FeatureDataset added to the path
# 
# Dean - 5/2022 
#

import arcpy, sys, csv, os, pandas as pd  

def ImportRules(Layer,csvFile,OutGDB):

    if Layer == "Taxlot" or Layer == "TaxlotNumberAnno":
        LayerToImport = OutGDB + "\\TaxlotsFD\\" + Layer
    else:
        LayerToImport= OutGDB + "\\" + Layer
    
    # Read CSV and get list of rules for layers
    
    df = pd.read_csv(csvFile)
    Rules = list(df["NAME"])
    Types = list(df["TYPE"])

    # Delete rules (fromcsv) for each Layer if it exists in GeoDB 
    
    print (Layer)
    desc = arcpy.Describe(LayerToImport).attributeRules
    #print (desc) 
    for rule in desc:
        RuleInFC = rule.name
        for RuleToDelete in Rules:
            if RuleToDelete == RuleInFC:
                print ('Layer: ' + Layer +  ' RuleToDelete: ' + RuleToDelete)
                arcpy.management.DeleteAttributeRule(LayerToImport, RuleToDelete)
         
    # Import rules for layer
    
    print ('LayerImportingRules: ' + Layer)
    arcpy.management.ImportAttributeRules(LayerToImport, csvFile)
    
# Main Program 

OutGDB = "C:\\ORMAP3.0\\T7-4\\Fabric\\TownEd.gdb"                    
Layers = ['Anno0100Scale','Anno0200Scale','Anno0400Scale','Anno2000Scale','Taxlot','CartographicLines','PLSSLines','WaterLines','ReferenceLines','ConstructionLines']
CSVFileLocation = "C:\\ORMAP3.0\\T7-4\\Fabric\RuleExports"

# Check for CSV for each layer if exists call importRules function

for Layer in Layers:
    csvFile = CSVFileLocation + "\\" + Layer + ".csv"
    if os.path.exists(csvFile): 
        ImportRules(Layer,csvFile,OutGDB)
    else:
        print('CSVFile: ' , + csvFile + ' does not exist') 

