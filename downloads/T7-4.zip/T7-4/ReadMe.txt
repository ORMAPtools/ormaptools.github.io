Overview 

Sample dataset to explore conversion, tools and attribute rules from Polk County Oregon

Fabric - Contains a one township sample dataset of converted data from ArcMap in ArcPro.
-- Default.gdb - Working GDB where temporary FC's are played with 
-- Geodb - Contains a one township sample of ArcMap data in Geodatabase "townedgeo.gdb". 
-- FabricConversion - Python scripts used for converted from ArcMap gdb to ArcPro gdb. 
-- ImportLog - ESRI folder 
-- Index - ESRI folder 
-- ORMAPTools - Folder containined ORMAP Tools 
-- RuleExports - Folder containing exported rules 
-- TownEd.gdb - ArcPro Geodatabase where converted ArcMap data is copied to (it has the data in it) 
-- TownEdbk.gdb - Backup ArcPro Geodatabase 
-- .pyHistory - ESRI File 
-- ArrowTools_Required_Scales.txt
-- Default.tbx - Toolbox that contains ORMAP Tools 
-- OrMapPF.aprx - Demo APRX Project file 

Geodb - Folder contains a township of ArcMap ORMAP data from Polk County built on ORMAP structure 

----------------------------------------------------------------
Installation 

Copy contents of T7-4 somewhere and run the ORMapPF.aprx to see the data. 
Look at internal "Readme.txt" for discussions about data paths. 

----------------------------------------------------------------
Update 3.0 = (Why 3.o - Cause moved to ParcelFabric Schema 5) 
Dean - 9/12/2022 

Running on ArcPro 2.94 

1. Upgraded dataset from Parcel Fabric Schema 4 to Schema 5 
2. Fixed paths for conversion scripts in T7-4/FabricConversion 
    -The are set to operate at "Library = 'C:\\ORMAP3.0\\T7-4'"
3. In T7-4 - for all "related" feature classes changed "RelatedFeatureClass" to GUID from Text 
    (This was already done for in the template) 
4. Updated "AP04-ImportFCs.py" so that county is automatically calculated (set it to your own) 
5. Fixed ORMAP Tool "UpdateORMAPArea - Was using field "TaxlotAcres" instead of "TaxlotAcre" 
6. Updated Taxlot Attributes for TaxlotFeet,TaxlotAcres, MapAcres (NumberFormat - 2 decimal Digits) 
7. Updated Taxlot_Lines Attributes for (Distance - 2 Decimal Digits & Pad with Zeros) 
     Note: If you replace Towned.gdb with TownedBK.gdb these will be gone. 
8. Added to scripts to export and import ALL attribute rules from a GDB 9 in "FabricConversion" folder. 
     "ExportAllAttributeRules.py" and "ImportAllAttributeRules.py"

----------------------------------------------------------------
Update 2.03 
Dean - 6/4/2022

1. Updated Annotation tasks. Added filters so that taxlots and taxlot_lines that were retired by record were not selected for calculating the correct underlying values. 
2. Created a new tool - UpdateORMAPArea that updates the taxlotfeet,taxlotacres, and mapacres fields for selected taxlots 
3. see #2 in the 2.02 update 
4. Update Mapindex feature class for county (it was empty before) it is now #27. 

----------------------------------------------------------------
Updates 2.02 
Dean - 4/16/2022 

1. Removed scripts that are not needed 
2. Taxlot Attribute Rules - fixed in the backup geodatabase (TownEdbk.gdb) - These were corrected earlier but if you replace the TownEd.gdb with the backup the rules will be bad again.  This has been fixed 
3. UpdateMapIndex - The Update MapIndex tool has been updated.  The MapScale now gets updated correctly in but the validate session and in the python script. In addition, the updatecursor in the update mapindex has been replaced with a search cursor.  

----------------------------------------------------------------
Updates 2.01 
Dean - 2/14/22

1. Attribute Domains - LineTypes - On Split set them to "Duplicate" rather then "Default" 
2. CalcMapTaxlot Taxlot Rule - Corrected error when taxlot was 3 charaters long had an extra "+" 
3. CalcCounty Taxlot Rule - Corrected error. Used MapNumber instead of county in one statement. 
4. ZoomTool Fix - When using SDE has a problem with null taxlots (fix sent from John) 
