Update 3.0 
Dean 9/10/2022 

This is the design for the ORMAP ArcPro Parcel Fabric.  The design was created to facilitate the conversion of data from ArcMap to ArcPro, to run ArcPro tools, and if desired to run ArcPro Fabric. 

Running on ArcPro 2.94 

1. Upgraded dataset from Parcel Fabric Schema 4 to Schema 5 
2. Changed "CreatedByRecord" from text to GUID in related FC's 



