ORMAP Tools Videos 
Sprint 2022 

The following videos illustrate how some of the basic ORMAP tools work.  Only one vidoe has sound (CreateDDAnnoFromLabels.mp4) the rest are only annotated. 

ORMAPPilotOverview.mp4 - a quick overview of where everything is in the T7-4 pilot/demo dataset 
ORMAPZoomToMap.mp4 - Zoom to taxmap and taxlot tool
OrMapAnnotationTasks.mp4 - Tasks to add annotation 
OrMapArrowTool.mp4 - Addin Arrow Tool (add specialized cartographic lines) 
ORMAPMapLayout.mp4 - A quick overview of the layout 
ORMAPUpdateMapIndex.mp4 - Update MapIndex tool 
CreateDDAnnoFromLabels.mp4 - Automatically place cogo dimension values into dimension annotation 
